﻿Imports System.Resources
Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' Le informazioni generali relative a un assembly sono controllate dal seguente 
' set di attributi. Modificare i valori di questi attributi per modificare le informazioni
' associate a un assembly.

' Rivedere i valori degli attributi degli assembly

<Assembly: AssemblyTitle("JustAPendulum companion")>
<Assembly: AssemblyDescription("JustAPendulum companion by marcocipriani01")>
<Assembly: AssemblyCompany("SqureBoot")>
<Assembly: AssemblyProduct("JustAPendulum companion")>
<Assembly: AssemblyCopyright("CC BY-NC-SA")>
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(False)>

'Se il progetto viene esposto a COM, il GUID seguente verrà utilizzato come ID della libreria dei tipi
<Assembly: Guid("57b6563c-c097-4bf8-b451-313adbb5f9cf")>

' Le informazioni sulla versione di un assembly sono costituite dai seguenti quattro valori:
'
'      Versione principale
'      Versione secondaria 
'      Numero di build
'      Revisione
'
' È possibile specificare tutti i valori oppure impostare valori predefiniti per i numeri relativi alla revisione e alla build 
' usando l'asterisco '*' come illustrato di seguito:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("3.0.0.0")>
<Assembly: AssemblyFileVersion("3.0.0.0")>
<Assembly: NeutralResourcesLanguage("en")>
