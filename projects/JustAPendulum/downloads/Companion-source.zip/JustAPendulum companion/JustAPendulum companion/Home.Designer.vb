﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Home
    Inherits System.Windows.Forms.Form

    'Form esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla mediante l'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ChartArea11 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend11 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series11 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim ChartArea12 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend12 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series12 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Home))
        Me.Connect = New System.Windows.Forms.Button()
        Me.Status = New System.Windows.Forms.StatusStrip()
        Me.StatusLabel = New System.Windows.Forms.ToolStripStatusLabel()
        Me.StatusBar = New System.Windows.Forms.ToolStripProgressBar()
        Me.Pendulum = New System.IO.Ports.SerialPort(Me.components)
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.CloseAnimation = New System.Windows.Forms.Button()
        Me.gBox = New System.Windows.Forms.TextBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.e_gBox = New System.Windows.Forms.TextBox()
        Me.PortsBox = New System.Windows.Forms.ComboBox()
        Me.PortsPanel = New System.Windows.Forms.Panel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.ErrorBox = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.PeriodBox = New System.Windows.Forms.TextBox()
        Me.Tabs = New System.Windows.Forms.TabControl()
        Me.MainPage = New System.Windows.Forms.TabPage()
        Me.TrackingSound = New System.Windows.Forms.CheckBox()
        Me.BallTracking = New System.Windows.Forms.CheckBox()
        Me.ControllerPage = New System.Windows.Forms.TabPage()
        Me.ChartsPage = New System.Windows.Forms.TabPage()
        Me.Charts = New System.Windows.Forms.TabControl()
        Me.gPage = New System.Windows.Forms.TabPage()
        Me.gChart = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.TPage = New System.Windows.Forms.TabPage()
        Me.TChart = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.TablesPage = New System.Windows.Forms.TabPage()
        Me.Table = New System.Windows.Forms.ListView()
        Me.PeriodTable = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.gTable = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.AdvacedPage = New System.Windows.Forms.TabPage()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.SpeedRating = New System.Windows.Forms.NumericUpDown()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.ADCMonitor = New System.Windows.Forms.CheckBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.A2Box = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.A1Box = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.A0Box = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.CalibrationGroup = New System.Windows.Forms.GroupBox()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.LengthButton = New System.Windows.Forms.Button()
        Me.eLengthPanel = New System.Windows.Forms.Panel()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.eLengthBox = New System.Windows.Forms.NumericUpDown()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.LengthPanel = New System.Windows.Forms.Panel()
        Me.LengthBox = New System.Windows.Forms.NumericUpDown()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Calibrate = New System.Windows.Forms.Button()
        Me.CalibrationPanel = New System.Windows.Forms.Panel()
        Me.CalibrateBox = New System.Windows.Forms.NumericUpDown()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.AboutMe = New System.Windows.Forms.TabPage()
        Me.Changelots = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Link = New System.Windows.Forms.LinkLabel()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.VersionBox = New System.Windows.Forms.Label()
        Me.SaveINI = New System.Windows.Forms.SaveFileDialog()
        Me.LoadINI = New System.Windows.Forms.OpenFileDialog()
        Me.Receiver = New System.Windows.Forms.Timer(Me.components)
        Me.AnimationTimer = New System.Windows.Forms.Timer(Me.components)
        Me.NotifyOptions = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.WelcomeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConnectdisconnectToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StartMeasurementsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AVRResetToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DisableToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AnimationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BallTrackingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ADCMonitorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClearAllToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConfigurationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CalibrationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WireLengthToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LoadINIToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveINIToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CloseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Notify = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.CloseButton = New System.Windows.Forms.Button()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.Animation = New System.Windows.Forms.PictureBox()
        Me.Start = New System.Windows.Forms.Button()
        Me.Reset = New System.Windows.Forms.Button()
        Me.Excel_export = New System.Windows.Forms.Button()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.Loader = New System.Windows.Forms.Button()
        Me.Saver = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.LogoPictureBox = New System.Windows.Forms.PictureBox()
        Me.Status.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.PortsPanel.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Tabs.SuspendLayout()
        Me.MainPage.SuspendLayout()
        Me.ControllerPage.SuspendLayout()
        Me.ChartsPage.SuspendLayout()
        Me.Charts.SuspendLayout()
        Me.gPage.SuspendLayout()
        CType(Me.gChart, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TPage.SuspendLayout()
        CType(Me.TChart, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TablesPage.SuspendLayout()
        Me.AdvacedPage.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.SpeedRating, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        Me.CalibrationGroup.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.eLengthPanel.SuspendLayout()
        CType(Me.eLengthBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.LengthPanel.SuspendLayout()
        CType(Me.LengthBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel5.SuspendLayout()
        Me.CalibrationPanel.SuspendLayout()
        CType(Me.CalibrateBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.AboutMe.SuspendLayout()
        Me.NotifyOptions.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Animation, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Connect
        '
        Me.Connect.BackColor = System.Drawing.Color.Lime
        Me.Connect.Font = New System.Drawing.Font("ISOCPEUR", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Connect.Location = New System.Drawing.Point(12, 12)
        Me.Connect.Name = "Connect"
        Me.Connect.Size = New System.Drawing.Size(168, 50)
        Me.Connect.TabIndex = 0
        Me.Connect.Text = "Connect"
        Me.Connect.UseVisualStyleBackColor = False
        '
        'Status
        '
        Me.Status.BackColor = System.Drawing.Color.White
        Me.Status.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StatusLabel, Me.StatusBar})
        Me.Status.Location = New System.Drawing.Point(0, 364)
        Me.Status.Name = "Status"
        Me.Status.Size = New System.Drawing.Size(607, 22)
        Me.Status.TabIndex = 3
        Me.Status.Text = "StatusStrip1"
        '
        'StatusLabel
        '
        Me.StatusLabel.BackColor = System.Drawing.Color.White
        Me.StatusLabel.Name = "StatusLabel"
        Me.StatusLabel.Size = New System.Drawing.Size(39, 17)
        Me.StatusLabel.Text = "Ready"
        '
        'StatusBar
        '
        Me.StatusBar.Name = "StatusBar"
        Me.StatusBar.Size = New System.Drawing.Size(100, 16)
        '
        'Pendulum
        '
        Me.Pendulum.BaudRate = 115200
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(3, 5)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(75, 18)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Simulator:"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel1.Controls.Add(Me.CloseAnimation)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.Animation)
        Me.Panel1.Location = New System.Drawing.Point(3, 6)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(225, 223)
        Me.Panel1.TabIndex = 1
        '
        'CloseAnimation
        '
        Me.CloseAnimation.BackColor = System.Drawing.Color.Red
        Me.CloseAnimation.Enabled = False
        Me.CloseAnimation.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CloseAnimation.Location = New System.Drawing.Point(182, 180)
        Me.CloseAnimation.Name = "CloseAnimation"
        Me.CloseAnimation.Size = New System.Drawing.Size(40, 40)
        Me.CloseAnimation.TabIndex = 0
        Me.CloseAnimation.Text = "X"
        Me.CloseAnimation.UseVisualStyleBackColor = False
        '
        'gBox
        '
        Me.gBox.Location = New System.Drawing.Point(3, 207)
        Me.gBox.Name = "gBox"
        Me.gBox.ReadOnly = True
        Me.gBox.Size = New System.Drawing.Size(106, 20)
        Me.gBox.TabIndex = 0
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.Label5)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Controls.Add(Me.e_gBox)
        Me.Panel2.Controls.Add(Me.PictureBox2)
        Me.Panel2.Controls.Add(Me.gBox)
        Me.Panel2.Location = New System.Drawing.Point(420, 6)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(156, 255)
        Me.Panel2.TabIndex = 0
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(115, 232)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(28, 13)
        Me.Label5.TabIndex = 3
        Me.Label5.Text = "m/s²"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(115, 210)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(28, 13)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "m/s²"
        '
        'e_gBox
        '
        Me.e_gBox.Location = New System.Drawing.Point(3, 229)
        Me.e_gBox.Name = "e_gBox"
        Me.e_gBox.ReadOnly = True
        Me.e_gBox.Size = New System.Drawing.Size(106, 20)
        Me.e_gBox.TabIndex = 1
        Me.e_gBox.Text = "±"
        '
        'PortsBox
        '
        Me.PortsBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.PortsBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.PortsBox.FormattingEnabled = True
        Me.PortsBox.Location = New System.Drawing.Point(64, 5)
        Me.PortsBox.Name = "PortsBox"
        Me.PortsBox.Size = New System.Drawing.Size(86, 21)
        Me.PortsBox.TabIndex = 0
        '
        'PortsPanel
        '
        Me.PortsPanel.Controls.Add(Me.Label3)
        Me.PortsPanel.Controls.Add(Me.PortsBox)
        Me.PortsPanel.Location = New System.Drawing.Point(186, 23)
        Me.PortsPanel.Name = "PortsPanel"
        Me.PortsPanel.Size = New System.Drawing.Size(155, 29)
        Me.PortsPanel.TabIndex = 1
        Me.PortsPanel.Visible = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(3, 9)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(55, 13)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "COM port:"
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.Label6)
        Me.Panel3.Controls.Add(Me.ErrorBox)
        Me.Panel3.Controls.Add(Me.Label2)
        Me.Panel3.Controls.Add(Me.PeriodBox)
        Me.Panel3.Controls.Add(Me.PictureBox3)
        Me.Panel3.Controls.Add(Me.PictureBox4)
        Me.Panel3.Location = New System.Drawing.Point(228, 32)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(186, 121)
        Me.Panel3.TabIndex = 2
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(85, 29)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(35, 13)
        Me.Label6.TabIndex = 2
        Me.Label6.Text = "±1 ms"
        '
        'ErrorBox
        '
        Me.ErrorBox.BackColor = System.Drawing.SystemColors.Control
        Me.ErrorBox.Location = New System.Drawing.Point(28, 84)
        Me.ErrorBox.Name = "ErrorBox"
        Me.ErrorBox.Size = New System.Drawing.Size(100, 20)
        Me.ErrorBox.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(163, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(20, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "ms"
        '
        'PeriodBox
        '
        Me.PeriodBox.BackColor = System.Drawing.SystemColors.Control
        Me.PeriodBox.Location = New System.Drawing.Point(83, 6)
        Me.PeriodBox.Name = "PeriodBox"
        Me.PeriodBox.Size = New System.Drawing.Size(74, 20)
        Me.PeriodBox.TabIndex = 0
        '
        'Tabs
        '
        Me.Tabs.Controls.Add(Me.MainPage)
        Me.Tabs.Controls.Add(Me.ControllerPage)
        Me.Tabs.Controls.Add(Me.ChartsPage)
        Me.Tabs.Controls.Add(Me.TablesPage)
        Me.Tabs.Controls.Add(Me.AdvacedPage)
        Me.Tabs.Controls.Add(Me.AboutMe)
        Me.Tabs.Location = New System.Drawing.Point(12, 68)
        Me.Tabs.Name = "Tabs"
        Me.Tabs.SelectedIndex = 0
        Me.Tabs.Size = New System.Drawing.Size(583, 288)
        Me.Tabs.TabIndex = 4
        '
        'MainPage
        '
        Me.MainPage.BackColor = System.Drawing.Color.White
        Me.MainPage.Controls.Add(Me.TrackingSound)
        Me.MainPage.Controls.Add(Me.BallTracking)
        Me.MainPage.Controls.Add(Me.Panel2)
        Me.MainPage.Controls.Add(Me.Panel3)
        Me.MainPage.Controls.Add(Me.Panel1)
        Me.MainPage.Location = New System.Drawing.Point(4, 22)
        Me.MainPage.Name = "MainPage"
        Me.MainPage.Padding = New System.Windows.Forms.Padding(3)
        Me.MainPage.Size = New System.Drawing.Size(575, 262)
        Me.MainPage.TabIndex = 0
        Me.MainPage.Text = "Main"
        '
        'TrackingSound
        '
        Me.TrackingSound.AutoSize = True
        Me.TrackingSound.Enabled = False
        Me.TrackingSound.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TrackingSound.Location = New System.Drawing.Point(231, 199)
        Me.TrackingSound.Name = "TrackingSound"
        Me.TrackingSound.Size = New System.Drawing.Size(115, 19)
        Me.TrackingSound.TabIndex = 4
        Me.TrackingSound.Text = "Play a frequency" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.TrackingSound.UseVisualStyleBackColor = True
        '
        'BallTracking
        '
        Me.BallTracking.AutoSize = True
        Me.BallTracking.Enabled = False
        Me.BallTracking.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BallTracking.Location = New System.Drawing.Point(231, 176)
        Me.BallTracking.Name = "BallTracking"
        Me.BallTracking.Size = New System.Drawing.Size(107, 22)
        Me.BallTracking.TabIndex = 3
        Me.BallTracking.Text = "Ball tracking"
        Me.BallTracking.UseVisualStyleBackColor = True
        '
        'ControllerPage
        '
        Me.ControllerPage.BackColor = System.Drawing.Color.White
        Me.ControllerPage.Controls.Add(Me.Start)
        Me.ControllerPage.Controls.Add(Me.Reset)
        Me.ControllerPage.Location = New System.Drawing.Point(4, 22)
        Me.ControllerPage.Name = "ControllerPage"
        Me.ControllerPage.Size = New System.Drawing.Size(575, 262)
        Me.ControllerPage.TabIndex = 2
        Me.ControllerPage.Text = "Controller"
        '
        'ChartsPage
        '
        Me.ChartsPage.BackColor = System.Drawing.Color.White
        Me.ChartsPage.Controls.Add(Me.Charts)
        Me.ChartsPage.Location = New System.Drawing.Point(4, 22)
        Me.ChartsPage.Name = "ChartsPage"
        Me.ChartsPage.Size = New System.Drawing.Size(575, 262)
        Me.ChartsPage.TabIndex = 5
        Me.ChartsPage.Text = "Charts"
        '
        'Charts
        '
        Me.Charts.Controls.Add(Me.gPage)
        Me.Charts.Controls.Add(Me.TPage)
        Me.Charts.Location = New System.Drawing.Point(3, 4)
        Me.Charts.Name = "Charts"
        Me.Charts.SelectedIndex = 0
        Me.Charts.Size = New System.Drawing.Size(568, 255)
        Me.Charts.TabIndex = 0
        '
        'gPage
        '
        Me.gPage.Controls.Add(Me.gChart)
        Me.gPage.Location = New System.Drawing.Point(4, 22)
        Me.gPage.Name = "gPage"
        Me.gPage.Padding = New System.Windows.Forms.Padding(3)
        Me.gPage.Size = New System.Drawing.Size(560, 229)
        Me.gPage.TabIndex = 0
        Me.gPage.Text = "Gravitational acceleration"
        Me.gPage.UseVisualStyleBackColor = True
        '
        'gChart
        '
        Me.gChart.BorderlineWidth = 10
        ChartArea11.Name = "ChartArea1"
        Me.gChart.ChartAreas.Add(ChartArea11)
        Legend11.Name = "Legend1"
        Me.gChart.Legends.Add(Legend11)
        Me.gChart.Location = New System.Drawing.Point(3, 6)
        Me.gChart.Name = "gChart"
        Me.gChart.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Excel
        Series11.ChartArea = "ChartArea1"
        Series11.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
        Series11.Color = System.Drawing.Color.Blue
        Series11.IsVisibleInLegend = False
        Series11.Legend = "Legend1"
        Series11.Name = "Gravitational acceleration"
        Me.gChart.Series.Add(Series11)
        Me.gChart.Size = New System.Drawing.Size(551, 217)
        Me.gChart.TabIndex = 38
        Me.gChart.Text = "Gravitational acceleration"
        '
        'TPage
        '
        Me.TPage.Controls.Add(Me.TChart)
        Me.TPage.Location = New System.Drawing.Point(4, 22)
        Me.TPage.Name = "TPage"
        Me.TPage.Padding = New System.Windows.Forms.Padding(3)
        Me.TPage.Size = New System.Drawing.Size(560, 229)
        Me.TPage.TabIndex = 1
        Me.TPage.Text = "Oscillation period"
        Me.TPage.UseVisualStyleBackColor = True
        '
        'TChart
        '
        Me.TChart.BorderlineWidth = 10
        ChartArea12.Name = "ChartArea1"
        Me.TChart.ChartAreas.Add(ChartArea12)
        Legend12.Name = "Legend1"
        Me.TChart.Legends.Add(Legend12)
        Me.TChart.Location = New System.Drawing.Point(3, 3)
        Me.TChart.Name = "TChart"
        Me.TChart.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Excel
        Series12.ChartArea = "ChartArea1"
        Series12.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
        Series12.Color = System.Drawing.Color.Blue
        Series12.IsVisibleInLegend = False
        Series12.Legend = "Legend1"
        Series12.Name = "Period"
        Me.TChart.Series.Add(Series12)
        Me.TChart.Size = New System.Drawing.Size(551, 217)
        Me.TChart.TabIndex = 39
        Me.TChart.Text = "Oscillation period"
        '
        'TablesPage
        '
        Me.TablesPage.Controls.Add(Me.Excel_export)
        Me.TablesPage.Controls.Add(Me.Table)
        Me.TablesPage.Location = New System.Drawing.Point(4, 22)
        Me.TablesPage.Name = "TablesPage"
        Me.TablesPage.Size = New System.Drawing.Size(575, 262)
        Me.TablesPage.TabIndex = 6
        Me.TablesPage.Text = "Tables"
        Me.TablesPage.UseVisualStyleBackColor = True
        '
        'Table
        '
        Me.Table.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.PeriodTable, Me.gTable})
        Me.Table.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Table.FullRowSelect = True
        Me.Table.GridLines = True
        Me.Table.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Table.Location = New System.Drawing.Point(0, 0)
        Me.Table.Name = "Table"
        Me.Table.Size = New System.Drawing.Size(575, 262)
        Me.Table.TabIndex = 0
        Me.Table.UseCompatibleStateImageBehavior = False
        Me.Table.View = System.Windows.Forms.View.Details
        '
        'PeriodTable
        '
        Me.PeriodTable.Text = "Oscillation period"
        Me.PeriodTable.Width = 230
        '
        'gTable
        '
        Me.gTable.Text = "Gravitational acceleration"
        Me.gTable.Width = 287
        '
        'AdvacedPage
        '
        Me.AdvacedPage.BackColor = System.Drawing.Color.White
        Me.AdvacedPage.Controls.Add(Me.GroupBox1)
        Me.AdvacedPage.Controls.Add(Me.GroupBox3)
        Me.AdvacedPage.Controls.Add(Me.CalibrationGroup)
        Me.AdvacedPage.Location = New System.Drawing.Point(4, 22)
        Me.AdvacedPage.Name = "AdvacedPage"
        Me.AdvacedPage.Padding = New System.Windows.Forms.Padding(3)
        Me.AdvacedPage.Size = New System.Drawing.Size(575, 262)
        Me.AdvacedPage.TabIndex = 1
        Me.AdvacedPage.Text = "Advanced"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label19)
        Me.GroupBox1.Controls.Add(Me.Label18)
        Me.GroupBox1.Controls.Add(Me.SpeedRating)
        Me.GroupBox1.Location = New System.Drawing.Point(6, 211)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(200, 45)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Receiving interval"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.Red
        Me.Label19.Location = New System.Drawing.Point(107, 21)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(69, 13)
        Me.Label19.TabIndex = 2
        Me.Label19.Text = "Be careful!"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(58, 21)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(20, 13)
        Me.Label18.TabIndex = 1
        Me.Label18.Text = "ms"
        '
        'SpeedRating
        '
        Me.SpeedRating.Location = New System.Drawing.Point(6, 19)
        Me.SpeedRating.Maximum = New Decimal(New Integer() {500, 0, 0, 0})
        Me.SpeedRating.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.SpeedRating.Name = "SpeedRating"
        Me.SpeedRating.Size = New System.Drawing.Size(46, 20)
        Me.SpeedRating.TabIndex = 0
        Me.SpeedRating.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.ADCMonitor)
        Me.GroupBox3.Controls.Add(Me.Label10)
        Me.GroupBox3.Controls.Add(Me.PictureBox5)
        Me.GroupBox3.Controls.Add(Me.A2Box)
        Me.GroupBox3.Controls.Add(Me.Label7)
        Me.GroupBox3.Controls.Add(Me.A1Box)
        Me.GroupBox3.Controls.Add(Me.Label8)
        Me.GroupBox3.Controls.Add(Me.A0Box)
        Me.GroupBox3.Controls.Add(Me.Label9)
        Me.GroupBox3.Location = New System.Drawing.Point(6, 10)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(200, 195)
        Me.GroupBox3.TabIndex = 0
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Sensor tester"
        '
        'ADCMonitor
        '
        Me.ADCMonitor.AutoSize = True
        Me.ADCMonitor.Enabled = False
        Me.ADCMonitor.Location = New System.Drawing.Point(6, 19)
        Me.ADCMonitor.Name = "ADCMonitor"
        Me.ADCMonitor.Size = New System.Drawing.Size(85, 17)
        Me.ADCMonitor.TabIndex = 0
        Me.ADCMonitor.Text = "ADC monitor"
        Me.ADCMonitor.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(107, 142)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(40, 16)
        Me.Label10.TabIndex = 7
        Me.Label10.Text = "/1023"
        '
        'A2Box
        '
        Me.A2Box.BackColor = System.Drawing.SystemColors.Control
        Me.A2Box.Location = New System.Drawing.Point(29, 167)
        Me.A2Box.Name = "A2Box"
        Me.A2Box.Size = New System.Drawing.Size(72, 20)
        Me.A2Box.TabIndex = 3
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(3, 116)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(23, 13)
        Me.Label7.TabIndex = 4
        Me.Label7.Text = "A0:"
        '
        'A1Box
        '
        Me.A1Box.BackColor = System.Drawing.SystemColors.Control
        Me.A1Box.Location = New System.Drawing.Point(29, 141)
        Me.A1Box.Name = "A1Box"
        Me.A1Box.Size = New System.Drawing.Size(72, 20)
        Me.A1Box.TabIndex = 2
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(3, 144)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(23, 13)
        Me.Label8.TabIndex = 5
        Me.Label8.Text = "A1:"
        '
        'A0Box
        '
        Me.A0Box.BackColor = System.Drawing.SystemColors.Control
        Me.A0Box.Location = New System.Drawing.Point(29, 113)
        Me.A0Box.Name = "A0Box"
        Me.A0Box.Size = New System.Drawing.Size(72, 20)
        Me.A0Box.TabIndex = 1
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(3, 170)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(23, 13)
        Me.Label9.TabIndex = 6
        Me.Label9.Text = "A2:"
        '
        'CalibrationGroup
        '
        Me.CalibrationGroup.Controls.Add(Me.Panel6)
        Me.CalibrationGroup.Controls.Add(Me.Panel5)
        Me.CalibrationGroup.Controls.Add(Me.Label13)
        Me.CalibrationGroup.Enabled = False
        Me.CalibrationGroup.Location = New System.Drawing.Point(216, 10)
        Me.CalibrationGroup.Name = "CalibrationGroup"
        Me.CalibrationGroup.Size = New System.Drawing.Size(260, 213)
        Me.CalibrationGroup.TabIndex = 1
        Me.CalibrationGroup.TabStop = False
        Me.CalibrationGroup.Text = "Calibration"
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.LengthButton)
        Me.Panel6.Controls.Add(Me.eLengthPanel)
        Me.Panel6.Controls.Add(Me.LengthPanel)
        Me.Panel6.Location = New System.Drawing.Point(7, 134)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(229, 73)
        Me.Panel6.TabIndex = 1
        '
        'LengthButton
        '
        Me.LengthButton.Location = New System.Drawing.Point(5, 14)
        Me.LengthButton.Name = "LengthButton"
        Me.LengthButton.Size = New System.Drawing.Size(108, 47)
        Me.LengthButton.TabIndex = 0
        Me.LengthButton.Text = "Wire length"
        Me.LengthButton.UseVisualStyleBackColor = True
        '
        'eLengthPanel
        '
        Me.eLengthPanel.Controls.Add(Me.Label16)
        Me.eLengthPanel.Controls.Add(Me.eLengthBox)
        Me.eLengthPanel.Controls.Add(Me.Label15)
        Me.eLengthPanel.Location = New System.Drawing.Point(122, 38)
        Me.eLengthPanel.Name = "eLengthPanel"
        Me.eLengthPanel.Size = New System.Drawing.Size(98, 28)
        Me.eLengthPanel.TabIndex = 2
        Me.eLengthPanel.Visible = False
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(3, 7)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(13, 13)
        Me.Label16.TabIndex = 0
        Me.Label16.Text = "±"
        '
        'eLengthBox
        '
        Me.eLengthBox.Location = New System.Drawing.Point(22, 3)
        Me.eLengthBox.Maximum = New Decimal(New Integer() {20, 0, 0, 0})
        Me.eLengthBox.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.eLengthBox.Name = "eLengthBox"
        Me.eLengthBox.Size = New System.Drawing.Size(46, 20)
        Me.eLengthBox.TabIndex = 1
        Me.eLengthBox.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(72, 7)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(23, 13)
        Me.Label15.TabIndex = 2
        Me.Label15.Text = "mm"
        '
        'LengthPanel
        '
        Me.LengthPanel.Controls.Add(Me.LengthBox)
        Me.LengthPanel.Controls.Add(Me.Label14)
        Me.LengthPanel.Location = New System.Drawing.Point(122, 7)
        Me.LengthPanel.Name = "LengthPanel"
        Me.LengthPanel.Size = New System.Drawing.Size(98, 28)
        Me.LengthPanel.TabIndex = 1
        Me.LengthPanel.Visible = False
        '
        'LengthBox
        '
        Me.LengthBox.DecimalPlaces = 3
        Me.LengthBox.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.LengthBox.Location = New System.Drawing.Point(3, 5)
        Me.LengthBox.Maximum = New Decimal(New Integer() {15, 0, 0, 65536})
        Me.LengthBox.Minimum = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.LengthBox.Name = "LengthBox"
        Me.LengthBox.Size = New System.Drawing.Size(72, 20)
        Me.LengthBox.TabIndex = 0
        Me.LengthBox.Value = New Decimal(New Integer() {74, 0, 0, 131072})
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(81, 7)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(15, 13)
        Me.Label14.TabIndex = 1
        Me.Label14.Text = "m"
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.Calibrate)
        Me.Panel5.Controls.Add(Me.Loader)
        Me.Panel5.Controls.Add(Me.CalibrationPanel)
        Me.Panel5.Controls.Add(Me.Saver)
        Me.Panel5.Location = New System.Drawing.Point(9, 15)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(247, 113)
        Me.Panel5.TabIndex = 0
        '
        'Calibrate
        '
        Me.Calibrate.Location = New System.Drawing.Point(3, 3)
        Me.Calibrate.Name = "Calibrate"
        Me.Calibrate.Size = New System.Drawing.Size(108, 47)
        Me.Calibrate.TabIndex = 0
        Me.Calibrate.Text = "Manual calibration"
        Me.Calibrate.UseVisualStyleBackColor = True
        '
        'CalibrationPanel
        '
        Me.CalibrationPanel.Controls.Add(Me.CalibrateBox)
        Me.CalibrationPanel.Controls.Add(Me.Label11)
        Me.CalibrationPanel.Location = New System.Drawing.Point(117, 13)
        Me.CalibrationPanel.Name = "CalibrationPanel"
        Me.CalibrationPanel.Size = New System.Drawing.Size(128, 28)
        Me.CalibrationPanel.TabIndex = 1
        Me.CalibrationPanel.Visible = False
        '
        'CalibrateBox
        '
        Me.CalibrateBox.Location = New System.Drawing.Point(3, 5)
        Me.CalibrateBox.Maximum = New Decimal(New Integer() {1023, 0, 0, 0})
        Me.CalibrateBox.Name = "CalibrateBox"
        Me.CalibrateBox.Size = New System.Drawing.Size(78, 20)
        Me.CalibrateBox.TabIndex = 0
        Me.CalibrateBox.Value = New Decimal(New Integer() {1000, 0, 0, 0})
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(85, 7)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(36, 13)
        Me.Label11.TabIndex = 1
        Me.Label11.Text = "/1023"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.Location = New System.Drawing.Point(6, 118)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(241, 13)
        Me.Label13.TabIndex = 2
        Me.Label13.Text = "_______________________________________"
        '
        'AboutMe
        '
        Me.AboutMe.BackColor = System.Drawing.Color.White
        Me.AboutMe.Controls.Add(Me.Changelots)
        Me.AboutMe.Controls.Add(Me.Label12)
        Me.AboutMe.Controls.Add(Me.Link)
        Me.AboutMe.Controls.Add(Me.Label17)
        Me.AboutMe.Controls.Add(Me.VersionBox)
        Me.AboutMe.Controls.Add(Me.PictureBox1)
        Me.AboutMe.Controls.Add(Me.LogoPictureBox)
        Me.AboutMe.Location = New System.Drawing.Point(4, 22)
        Me.AboutMe.Name = "AboutMe"
        Me.AboutMe.Size = New System.Drawing.Size(575, 262)
        Me.AboutMe.TabIndex = 4
        Me.AboutMe.Text = "About me"
        '
        'Changelots
        '
        Me.Changelots.Cursor = System.Windows.Forms.Cursors.Help
        Me.Changelots.Location = New System.Drawing.Point(136, 64)
        Me.Changelots.Multiline = True
        Me.Changelots.Name = "Changelots"
        Me.Changelots.ReadOnly = True
        Me.Changelots.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Changelots.Size = New System.Drawing.Size(418, 105)
        Me.Changelots.TabIndex = 8
        Me.Changelots.Text = resources.GetString("Changelots.Text")
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(314, 12)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(134, 24)
        Me.Label12.TabIndex = 7
        Me.Label12.Text = "by marcocipriani01"
        '
        'Link
        '
        Me.Link.AutoSize = True
        Me.Link.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Link.Location = New System.Drawing.Point(133, 12)
        Me.Link.Name = "Link"
        Me.Link.Size = New System.Drawing.Size(175, 25)
        Me.Link.TabIndex = 6
        Me.Link.TabStop = True
        Me.Link.Text = "JustAPendulum"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(133, 224)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(398, 26)
        Me.Label17.TabIndex = 5
        Me.Label17.Text = "JustAPendulum by marcocipriani01 is licensed under a" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Creative Commons Attribution-Non" &
    "Commercial-ShareAlike 4.0 International License."
        '
        'VersionBox
        '
        Me.VersionBox.AutoSize = True
        Me.VersionBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.VersionBox.Location = New System.Drawing.Point(135, 46)
        Me.VersionBox.Name = "VersionBox"
        Me.VersionBox.Size = New System.Drawing.Size(69, 15)
        Me.VersionBox.TabIndex = 3
        Me.VersionBox.Text = "VersionBox"
        '
        'SaveINI
        '
        Me.SaveINI.Filter = "Configuration file (.ini)|*.ini"
        Me.SaveINI.RestoreDirectory = True
        Me.SaveINI.Title = "Save a configuration file"
        '
        'LoadINI
        '
        Me.LoadINI.Filter = "Configuration file (.ini)|*.ini"
        Me.LoadINI.RestoreDirectory = True
        Me.LoadINI.Title = "Load a configuration file"
        '
        'Receiver
        '
        Me.Receiver.Interval = 1
        '
        'AnimationTimer
        '
        '
        'NotifyOptions
        '
        Me.NotifyOptions.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.WelcomeToolStripMenuItem, Me.ConnectdisconnectToolStripMenuItem, Me.StartMeasurementsToolStripMenuItem, Me.AVRResetToolStripMenuItem, Me.DisableToolStripMenuItem, Me.ClearAllToolStripMenuItem, Me.ConfigurationToolStripMenuItem, Me.CloseToolStripMenuItem})
        Me.NotifyOptions.Name = "NotifyMenù"
        Me.NotifyOptions.Size = New System.Drawing.Size(183, 180)
        '
        'WelcomeToolStripMenuItem
        '
        Me.WelcomeToolStripMenuItem.Enabled = False
        Me.WelcomeToolStripMenuItem.Name = "WelcomeToolStripMenuItem"
        Me.WelcomeToolStripMenuItem.Size = New System.Drawing.Size(182, 22)
        Me.WelcomeToolStripMenuItem.Text = "Welcome!"
        '
        'ConnectdisconnectToolStripMenuItem
        '
        Me.ConnectdisconnectToolStripMenuItem.Name = "ConnectdisconnectToolStripMenuItem"
        Me.ConnectdisconnectToolStripMenuItem.Size = New System.Drawing.Size(182, 22)
        Me.ConnectdisconnectToolStripMenuItem.Text = "Connect/disconnect"
        '
        'StartMeasurementsToolStripMenuItem
        '
        Me.StartMeasurementsToolStripMenuItem.Name = "StartMeasurementsToolStripMenuItem"
        Me.StartMeasurementsToolStripMenuItem.Size = New System.Drawing.Size(182, 22)
        Me.StartMeasurementsToolStripMenuItem.Text = "Start measurements"
        '
        'AVRResetToolStripMenuItem
        '
        Me.AVRResetToolStripMenuItem.Name = "AVRResetToolStripMenuItem"
        Me.AVRResetToolStripMenuItem.Size = New System.Drawing.Size(182, 22)
        Me.AVRResetToolStripMenuItem.Text = "AVR reset"
        '
        'DisableToolStripMenuItem
        '
        Me.DisableToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AnimationToolStripMenuItem, Me.BallTrackingToolStripMenuItem, Me.ADCMonitorToolStripMenuItem})
        Me.DisableToolStripMenuItem.Name = "DisableToolStripMenuItem"
        Me.DisableToolStripMenuItem.Size = New System.Drawing.Size(182, 22)
        Me.DisableToolStripMenuItem.Text = "Disable"
        '
        'AnimationToolStripMenuItem
        '
        Me.AnimationToolStripMenuItem.Name = "AnimationToolStripMenuItem"
        Me.AnimationToolStripMenuItem.Size = New System.Drawing.Size(144, 22)
        Me.AnimationToolStripMenuItem.Text = "Animation"
        '
        'BallTrackingToolStripMenuItem
        '
        Me.BallTrackingToolStripMenuItem.Name = "BallTrackingToolStripMenuItem"
        Me.BallTrackingToolStripMenuItem.Size = New System.Drawing.Size(144, 22)
        Me.BallTrackingToolStripMenuItem.Text = "Ball tracking"
        '
        'ADCMonitorToolStripMenuItem
        '
        Me.ADCMonitorToolStripMenuItem.Name = "ADCMonitorToolStripMenuItem"
        Me.ADCMonitorToolStripMenuItem.Size = New System.Drawing.Size(144, 22)
        Me.ADCMonitorToolStripMenuItem.Text = "ADC monitor"
        '
        'ClearAllToolStripMenuItem
        '
        Me.ClearAllToolStripMenuItem.Name = "ClearAllToolStripMenuItem"
        Me.ClearAllToolStripMenuItem.Size = New System.Drawing.Size(182, 22)
        Me.ClearAllToolStripMenuItem.Text = "Clear all"
        '
        'ConfigurationToolStripMenuItem
        '
        Me.ConfigurationToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CalibrationToolStripMenuItem, Me.WireLengthToolStripMenuItem, Me.LoadINIToolStripMenuItem, Me.SaveINIToolStripMenuItem})
        Me.ConfigurationToolStripMenuItem.Name = "ConfigurationToolStripMenuItem"
        Me.ConfigurationToolStripMenuItem.Size = New System.Drawing.Size(182, 22)
        Me.ConfigurationToolStripMenuItem.Text = "Configuration"
        '
        'CalibrationToolStripMenuItem
        '
        Me.CalibrationToolStripMenuItem.Name = "CalibrationToolStripMenuItem"
        Me.CalibrationToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.CalibrationToolStripMenuItem.Text = "Calibration"
        '
        'WireLengthToolStripMenuItem
        '
        Me.WireLengthToolStripMenuItem.Name = "WireLengthToolStripMenuItem"
        Me.WireLengthToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.WireLengthToolStripMenuItem.Text = "Wire length"
        '
        'LoadINIToolStripMenuItem
        '
        Me.LoadINIToolStripMenuItem.Name = "LoadINIToolStripMenuItem"
        Me.LoadINIToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.LoadINIToolStripMenuItem.Text = "Load INI"
        '
        'SaveINIToolStripMenuItem
        '
        Me.SaveINIToolStripMenuItem.Name = "SaveINIToolStripMenuItem"
        Me.SaveINIToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.SaveINIToolStripMenuItem.Text = "Save INI"
        '
        'CloseToolStripMenuItem
        '
        Me.CloseToolStripMenuItem.Name = "CloseToolStripMenuItem"
        Me.CloseToolStripMenuItem.Size = New System.Drawing.Size(182, 22)
        Me.CloseToolStripMenuItem.Text = "Close"
        '
        'Notify
        '
        Me.Notify.BalloonTipText = "Welcome to the companion :-)"
        Me.Notify.BalloonTipTitle = "JustAPendulum"
        Me.Notify.ContextMenuStrip = Me.NotifyOptions
        Me.Notify.Icon = CType(resources.GetObject("Notify.Icon"), System.Drawing.Icon)
        Me.Notify.Text = "JustAPendulum companion"
        Me.Notify.Visible = True
        '
        'CloseButton
        '
        Me.CloseButton.BackColor = System.Drawing.Color.Red
        Me.CloseButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CloseButton.ForeColor = System.Drawing.Color.White
        Me.CloseButton.Location = New System.Drawing.Point(562, 0)
        Me.CloseButton.Name = "CloseButton"
        Me.CloseButton.Size = New System.Drawing.Size(45, 45)
        Me.CloseButton.TabIndex = 2
        Me.CloseButton.Text = "X"
        Me.CloseButton.UseVisualStyleBackColor = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.JustAPendulum_companion.My.Resources.Resources.g
        Me.PictureBox2.Location = New System.Drawing.Point(3, 3)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(106, 198)
        Me.PictureBox2.TabIndex = 7
        Me.PictureBox2.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.JustAPendulum_companion.My.Resources.Resources.Clock
        Me.PictureBox3.Location = New System.Drawing.Point(3, 3)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(76, 75)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox3.TabIndex = 0
        Me.PictureBox3.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.Image = Global.JustAPendulum_companion.My.Resources.Resources.Epsilon
        Me.PictureBox4.Location = New System.Drawing.Point(3, 71)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(31, 42)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox4.TabIndex = 8
        Me.PictureBox4.TabStop = False
        '
        'Animation
        '
        Me.Animation.Image = Global.JustAPendulum_companion.My.Resources.Resources.Fist
        Me.Animation.Location = New System.Drawing.Point(6, 26)
        Me.Animation.Name = "Animation"
        Me.Animation.Size = New System.Drawing.Size(213, 185)
        Me.Animation.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Animation.TabIndex = 4
        Me.Animation.TabStop = False
        '
        'Start
        '
        Me.Start.BackColor = System.Drawing.Color.Gold
        Me.Start.Enabled = False
        Me.Start.Image = Global.JustAPendulum_companion.My.Resources.Resources.Start
        Me.Start.Location = New System.Drawing.Point(103, 69)
        Me.Start.Name = "Start"
        Me.Start.Size = New System.Drawing.Size(115, 90)
        Me.Start.TabIndex = 0
        Me.Start.UseVisualStyleBackColor = False
        '
        'Reset
        '
        Me.Reset.BackColor = System.Drawing.Color.DarkOrange
        Me.Reset.Enabled = False
        Me.Reset.Image = Global.JustAPendulum_companion.My.Resources.Resources.Reset
        Me.Reset.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Reset.Location = New System.Drawing.Point(234, 89)
        Me.Reset.Name = "Reset"
        Me.Reset.Size = New System.Drawing.Size(100, 50)
        Me.Reset.TabIndex = 1
        Me.Reset.Text = "AVR Reset"
        Me.Reset.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Reset.UseVisualStyleBackColor = False
        '
        'Excel_export
        '
        Me.Excel_export.Image = Global.JustAPendulum_companion.My.Resources.Resources.Excel_logo
        Me.Excel_export.Location = New System.Drawing.Point(495, 197)
        Me.Excel_export.Name = "Excel_export"
        Me.Excel_export.Size = New System.Drawing.Size(62, 62)
        Me.Excel_export.TabIndex = 1
        Me.Excel_export.UseVisualStyleBackColor = True
        '
        'PictureBox5
        '
        Me.PictureBox5.Image = Global.JustAPendulum_companion.My.Resources.Resources.ADC
        Me.PictureBox5.Location = New System.Drawing.Point(3, 42)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(191, 65)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox5.TabIndex = 3
        Me.PictureBox5.TabStop = False
        '
        'Loader
        '
        Me.Loader.Image = Global.JustAPendulum_companion.My.Resources.Resources.load
        Me.Loader.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Loader.Location = New System.Drawing.Point(3, 56)
        Me.Loader.Name = "Loader"
        Me.Loader.Size = New System.Drawing.Size(108, 47)
        Me.Loader.TabIndex = 2
        Me.Loader.Text = "Load INI"
        Me.Loader.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Loader.UseVisualStyleBackColor = True
        '
        'Saver
        '
        Me.Saver.Image = Global.JustAPendulum_companion.My.Resources.Resources.save
        Me.Saver.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Saver.Location = New System.Drawing.Point(117, 56)
        Me.Saver.Name = "Saver"
        Me.Saver.Size = New System.Drawing.Size(108, 47)
        Me.Saver.TabIndex = 3
        Me.Saver.Text = "Save INI"
        Me.Saver.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Saver.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.JustAPendulum_companion.My.Resources.Resources.CC
        Me.PictureBox1.Location = New System.Drawing.Point(138, 186)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(94, 35)
        Me.PictureBox1.TabIndex = 4
        Me.PictureBox1.TabStop = False
        '
        'LogoPictureBox
        '
        Me.LogoPictureBox.Image = Global.JustAPendulum_companion.My.Resources.Resources.Logo
        Me.LogoPictureBox.Location = New System.Drawing.Point(3, 3)
        Me.LogoPictureBox.Name = "LogoPictureBox"
        Me.LogoPictureBox.Size = New System.Drawing.Size(124, 256)
        Me.LogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.LogoPictureBox.TabIndex = 1
        Me.LogoPictureBox.TabStop = False
        '
        'Home
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Silver
        Me.ClientSize = New System.Drawing.Size(607, 386)
        Me.ControlBox = False
        Me.Controls.Add(Me.CloseButton)
        Me.Controls.Add(Me.Tabs)
        Me.Controls.Add(Me.PortsPanel)
        Me.Controls.Add(Me.Status)
        Me.Controls.Add(Me.Connect)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Home"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "JustAPendulum companion by marcocipriani01"
        Me.Status.ResumeLayout(False)
        Me.Status.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.PortsPanel.ResumeLayout(False)
        Me.PortsPanel.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Tabs.ResumeLayout(False)
        Me.MainPage.ResumeLayout(False)
        Me.MainPage.PerformLayout()
        Me.ControllerPage.ResumeLayout(False)
        Me.ChartsPage.ResumeLayout(False)
        Me.Charts.ResumeLayout(False)
        Me.gPage.ResumeLayout(False)
        CType(Me.gChart, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TPage.ResumeLayout(False)
        CType(Me.TChart, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TablesPage.ResumeLayout(False)
        Me.AdvacedPage.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.SpeedRating, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.CalibrationGroup.ResumeLayout(False)
        Me.CalibrationGroup.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.eLengthPanel.ResumeLayout(False)
        Me.eLengthPanel.PerformLayout()
        CType(Me.eLengthBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.LengthPanel.ResumeLayout(False)
        Me.LengthPanel.PerformLayout()
        CType(Me.LengthBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel5.ResumeLayout(False)
        Me.CalibrationPanel.ResumeLayout(False)
        Me.CalibrationPanel.PerformLayout()
        CType(Me.CalibrateBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.AboutMe.ResumeLayout(False)
        Me.AboutMe.PerformLayout()
        Me.NotifyOptions.ResumeLayout(False)
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Animation, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Connect As Button
    Friend WithEvents Status As StatusStrip
    Friend WithEvents Pendulum As IO.Ports.SerialPort
    Friend WithEvents StatusLabel As ToolStripStatusLabel
    Friend WithEvents StatusBar As ToolStripProgressBar
    Friend WithEvents Animation As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents gBox As TextBox
    Friend WithEvents PortsBox As ComboBox
    Friend WithEvents e_gBox As TextBox
    Friend WithEvents PortsPanel As Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents ErrorBox As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents PeriodBox As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Tabs As TabControl
    Friend WithEvents MainPage As TabPage
    Friend WithEvents AdvacedPage As TabPage
    Friend WithEvents ControllerPage As TabPage
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents Loader As Button
    Friend WithEvents Calibrate As Button
    Friend WithEvents Label10 As Label
    Friend WithEvents A2Box As TextBox
    Friend WithEvents A1Box As TextBox
    Friend WithEvents A0Box As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents CalibrationPanel As Panel
    Friend WithEvents Label11 As Label
    Friend WithEvents SaveINI As SaveFileDialog
    Friend WithEvents LoadINI As OpenFileDialog
    Friend WithEvents Receiver As Timer
    Friend WithEvents AnimationTimer As Timer
    Friend WithEvents CloseAnimation As Button
    Friend WithEvents Reset As Button
    Friend WithEvents ADCMonitor As CheckBox
    Friend WithEvents CalibrateBox As NumericUpDown
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents CalibrationGroup As GroupBox
    Friend WithEvents Saver As Button
    Friend WithEvents BallTracking As CheckBox
    Friend WithEvents Panel6 As Panel
    Friend WithEvents LengthButton As Button
    Friend WithEvents eLengthPanel As Panel
    Friend WithEvents eLengthBox As NumericUpDown
    Friend WithEvents Label15 As Label
    Friend WithEvents LengthPanel As Panel
    Friend WithEvents LengthBox As NumericUpDown
    Friend WithEvents Label14 As Label
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Label13 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Start As Button
    Friend WithEvents AboutMe As TabPage
    Friend WithEvents NotifyOptions As ContextMenuStrip
    Friend WithEvents WelcomeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ConnectdisconnectToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents StartMeasurementsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AVRResetToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DisableToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AnimationToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BallTrackingToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ADCMonitorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ClearAllToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ConfigurationToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CalibrationToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents WireLengthToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LoadINIToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SaveINIToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CloseToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CloseButton As Button
    Friend WithEvents LogoPictureBox As PictureBox
    Friend WithEvents VersionBox As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label17 As Label
    Friend WithEvents Link As LinkLabel
    Friend WithEvents Label12 As Label
    Friend WithEvents ChartsPage As TabPage
    Friend WithEvents Charts As TabControl
    Friend WithEvents gPage As TabPage
    Friend WithEvents gChart As DataVisualization.Charting.Chart
    Friend WithEvents TPage As TabPage
    Friend WithEvents TChart As DataVisualization.Charting.Chart
    Friend WithEvents TablesPage As TabPage
    Friend WithEvents Table As ListView
    Friend WithEvents PeriodTable As ColumnHeader
    Friend WithEvents gTable As ColumnHeader
    Friend WithEvents Changelots As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label19 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents SpeedRating As NumericUpDown
    Friend WithEvents Excel_export As Button
    Friend WithEvents TrackingSound As CheckBox
    Friend WithEvents Notify As NotifyIcon
End Class
