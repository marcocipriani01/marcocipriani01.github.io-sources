﻿Public Class CloseForm
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Home.Close()
    End Sub
End Class