﻿Imports System.IO.Ports

Public Class Home
    Dim ports As Array              'All the available ports
    Dim frame As Integer = 0        'The current frame of the animation
    Dim received As String = ""
    Dim CurrentPos As Integer = 1   'Position for the PlaySound() function

    Private Sub Connect_Click(sender As Object, e As EventArgs) Handles Connect.Click
        ConnectToPendulum()
    End Sub

    Private Sub ConnectToPendulum()     'Connect or disconnect
        setStatus("Connecting...", 1, 7)
        If Connect.Text = "Connect" Then
            ports = SerialPort.GetPortNames()
            setStatus("Skip", 2)
            'Automatically select a port from the ports list, else displays a ComboBox
            If UBound(ports) = 0 Then   'Only one COM port is available
                startConnection(ports(0))
            ElseIf UBound(ports) > 0 Then   'More ports available
                PortsBox.Items.AddRange(ports)
                setStatus("Select a COM port")
                PortsPanel.Visible = True
            ElseIf UBound(ports) = -1 Then  'No ports
                My.Computer.Audio.PlaySystemSound(Media.SystemSounds.Exclamation)
                setStatus("No ports detected")
            End If

        ElseIf Connect.Text = "Disconnect" Then     'Disconnection
            Try     'Disconnection
                CalibrationGroup.Enabled = False
                CalibrationPanel.Hide()
                LengthPanel.Hide()
                eLengthPanel.Hide()
                Start.Enabled = False
                Receiver.Stop()
                Pendulum.Close()
                CalibrationPanel.Hide()
                BallTracking.Enabled = False
                TrackingSound.Enabled = False
                Connect.BackColor = Color.Lime
                Reset.Enabled = False
                ADCMonitor.Enabled = False
                Connect.Text = "Connect"
                setStatus("Ready", 0, 0)
            Catch ex As Exception
                Debug.Print("Unable to disconnect: " & ex.Message)
                setStatus("Unable to disconnect!")
            End Try
        End If
    End Sub

    Private Sub startConnection(COMPort As String)  'Connection to a COM port
        Try
            setStatus("Skip", 3)
            Pendulum.PortName = COMPort
            setStatus("Skip", 4)
            Pendulum.Open()
            setStatus("Skip", 5)
            Receiver.Start()
            setStatus("Skip", 6)
            Reset.Enabled = True
            PortsPanel.Visible = False
            Connect.BackColor = Color.Red
            ADCMonitor.Enabled = True
            BallTracking.Enabled = True
            CalibrationGroup.Enabled = True
            Start.Enabled = True
            Connect.Text = "Disconnect"
            setStatus("Ready", 0, 0)

        Catch ex As Exception
            Debug.Print("Unable to connect: " & ex.Message)
            setStatus("An error has occurred during the connection!")
        End Try
    End Sub

    Private Sub setStatus(labelText As String, Optional progressBarValue As Integer = 9999, Optional progressBarMax As Integer = 9999)
        'This sub change the status displayed under the window
        If labelText <> "Skip" Then
            StatusLabel.Text = labelText
        End If
        If progressBarMax <> 9999 Then
            StatusBar.Maximum = progressBarMax
        End If
        If progressBarValue <> 9999 Then
            StatusBar.Value = progressBarValue
        End If
    End Sub

    Private Sub Pendulum_DataReceived(sender As Object, e As EventArgs) Handles Pendulum.DataReceived
        Try
            received = Pendulum.ReadLine()  'Save the received value into a variable
        Catch ex As Exception
            setStatus("Error during reading!")
            Debug.Print("Error during reading: " & ex.Message)
        End Try
    End Sub

    Private Sub Receiver_Tick(sender As Object, e As EventArgs) Handles Receiver.Tick
        If ADCMonitor.Checked = False And BallTracking.Checked = False Then
            'If they're disabled, process the information

            If received.StartsWith("Gravitational acceleration: ") Then
                gBox.Text = received.Replace("Gravitational acceleration: ", "").Replace(" m/s^2", "")
                'Chart
                gChart.Series("Gravitational acceleration").Points.AddXY("", gBox.Text)
                'Table
                Try
                    If Table.Items.Count = 0 Then
                        Table.Items(0).SubItems.Add(gBox.Text)
                    Else
                        Table.Items(Table.Items.Count - 1).SubItems.Add(gBox.Text)
                    End If
                Catch ex As Exception
                    setStatus("Internal error at Table.Items(0).")
                    Debug.Print("Table.Items error: " & ex.ToString)
                End Try

            ElseIf received.StartsWith("Oscillation period: ") Then
                'Save the value
                PeriodBox.Text = received.Replace("Oscillation period: ", "").Replace(" ms", "")
                'Reset the timer
                AnimationTimer.Stop()
                'Set the oscillation period
                AnimationTimer.Interval = Val(PeriodBox.Text) / 4
                frame = 0
                Animation.Image = My.Resources.Fist
                CloseAnimation.Enabled = True
                'Restart the animation
                AnimationTimer.Start()

                'Chart
                TChart.Series("Period").Points.AddXY("", PeriodBox.Text)
                'Table
                Table.Items.Add(PeriodBox.Text)

            ElseIf received.StartsWith("Relative error: ") Then
                ErrorBox.Text = received.Replace("Relative error: ", "")

            ElseIf received.StartsWith("e= ") Then
                e_gBox.Text = "±" & received.Replace("e= ", "").Replace(" m/s^2", "")
            End If

        ElseIf ADCMonitor.Checked = True And BallTracking.Checked = False Then
            'ADC monitor
            Try
                received = "Null"
                Pendulum.WriteLine(3)   'Arduino command

                While received = "Null"
                    'Wait the values
                    'WARNING: non-fixed bug with other Arduino firmwares or CPU off
                End While

                'Split the received string to get the values
                Dim ADC_values() As String = received.Split(",")
                A0Box.Text = ADC_values(0)
                A1Box.Text = ADC_values(1)
                A2Box.Text = ADC_values(2)

            Catch ex As Exception
                'Error messages
                setStatus("Unable to get ADC information!")
                Debug.Print("Unable to get ADC information: " & ex.Message)
            End Try

        ElseIf BallTracking.Checked = True And ADCMonitor.Checked = False Then
            'Tracking
            If received.StartsWith("Pos: ") Then    'Get the current position of the ball

                If received.StartsWith("Pos: 1") Then
                    Animation.Image = My.Resources.Fist
                    PlaySound(1)
                    CurrentPos = 1

                ElseIf received.StartsWith("Pos: 2") Then
                    Animation.Image = My.Resources.Second
                    PlaySound(2)
                    CurrentPos = 2

                ElseIf received.StartsWith("Pos: 3") Then
                    Animation.Image = My.Resources.Third
                    PlaySound(3)
                    CurrentPos = 3
                End If
            End If
            Pendulum.WriteLine(4)   'Send a command to the board: "I need the current position!"

        ElseIf BallTracking.Checked = True And ADCMonitor.Checked = True Then
            'Error message
            setStatus("Ball tracking and ADC monitor can't run at the same time!")
        End If

        'Reset the received text (don't delete this line!)
        received = ""
    End Sub

    Private Sub PlaySound(NewFrame As Integer)
        'Play a frequency whenever the ball changes his position
        If NewFrame <> CurrentPos And TrackingSound.Checked = True Then
            My.Computer.Audio.Play(My.Resources.FastBeep, AudioPlayMode.Background)
        End If
    End Sub

    Private Sub AnimationTimer_Tick(sender As Object, e As EventArgs) Handles AnimationTimer.Tick
        'Change the frame of the PictureBox
        If frame = 0 Then
            Animation.Image = My.Resources.Second
            frame = 1
        ElseIf frame = 1 Then
            Animation.Image = My.Resources.Third
            frame = 2
        ElseIf frame = 2 Then
            Animation.Image = My.Resources.Second
            frame = 3
        ElseIf frame = 3 Then
            Animation.Image = My.Resources.Fist
            frame = 0
        End If
    End Sub

    Private Sub Disable_Animation()
        'Close the animation (AnimationTimer_Tick() will be disabled)
        AnimationTimer.Stop()
        'Reset the frame
        frame = 0
        Animation.Image = My.Resources.Fist
        CloseAnimation.Enabled = False
    End Sub

    Private Sub CloseAnimation_Click(sender As Object, e As EventArgs) Handles CloseAnimation.Click
        Disable_Animation()
    End Sub

    Private Sub Reset_Click(sender As Object, e As EventArgs) Handles Reset.Click
        Try
            Pendulum.WriteLine(2)   'Reset command
        Catch ex As Exception
            setStatus("Unable to send the command!")
            Debug.Print("Unable to set the command: " & ex.Message)
        End Try
    End Sub

    Private Sub Calibrate_Click(sender As Object, e As EventArgs) Handles Calibrate.Click
        StartCalibration()
    End Sub

    Private Sub StartCalibration()  'Calibration sub
        ADCMonitor.Checked = False
        BallTracking.Checked = False
        Disable_Animation()
        Calibrate.Enabled = False
        LengthButton.Enabled = False
        Loader.Enabled = False
        Saver.Enabled = False
        CalibrationPanel.Show()
    End Sub

    Private Sub CalibrateBox_KeyPress(sender As Object, e As KeyPressEventArgs) Handles CalibrateBox.KeyPress
        'When I press the enter key the companion send the value
        Try
            If e.KeyChar = ChrW(Keys.Enter) Then
                Pendulum.WriteLine(CalibrateBox.Value + 50)
                CalibrationPanel.Hide()
                Calibrate.Enabled = True
                LengthButton.Enabled = True
                Loader.Enabled = True
                Saver.Enabled = True
            End If
        Catch ex As Exception
            setStatus("Unable to calibrate.")
            Debug.Print("Unable to calibrate: " & ex.Message)
        End Try
    End Sub

    Private Sub Loader_Click(sender As Object, e As EventArgs) Handles Loader.Click
        StartLoading()
    End Sub

    Private Sub StartLoading()  'Load an INI file that contains the calibration values
        Try
            setStatus("Loading file...", 0, 7)

            If LoadINI.ShowDialog() = DialogResult.OK Then
                setStatus("Skip", 1)
                Disable_Animation()
                Dim reader As New IO.StreamReader(LoadINI.FileName)
                setStatus("Skip", 2)

                While reader.Peek <> -1
                    Dim LastLine As String = reader.ReadLine()
                    If LastLine.StartsWith("[JustAPendulum]") Then
                        setStatus("Skip", 3)

                    ElseIf LastLine.StartsWith("Calibration_value = ") Then
                        LastLine = LastLine.Replace("Calibration_value = ", "")
                        CalibrateBox.Value = Val(LastLine)
                        Pendulum.WriteLine(Val(LastLine) + 50)
                        setStatus("Skip", 4)

                    ElseIf LastLine.StartsWith("Length = ") Then
                        LastLine = LastLine.Replace("Length = ", "")
                        LengthBox.Value = Val(LastLine)
                        Pendulum.WriteLine(Val(LastLine) + 1080)
                        setStatus("Skip", 5)

                    ElseIf LastLine.StartsWith("Length_error = ") Then
                        LastLine = LastLine.Replace("Length_error = ", "")
                        eLengthBox.Value = Val(LastLine)
                        Pendulum.WriteLine(Val(LastLine) + 3090)
                        setStatus("Skip", 6)
                    End If
                End While

                reader.Close()
                setStatus("Loaded succesfully! Ready", 7)
            End If
        Catch ex As Exception
            setStatus("Unable to load this file.")
            Debug.Print("Unable to load this file: " & ex.Message)
        End Try
    End Sub

    Private Sub Saver_Click(sender As Object, e As EventArgs) Handles Saver.Click
        StartSaving()
    End Sub

    Private Sub StartSaving()   'Save an INI file that contains the calibration values
        Try
            setStatus("Saving...", 0, 7)
            If SaveINI.ShowDialog() = DialogResult.OK Then
                setStatus("Skip", 1)
                Dim writer As New IO.StreamWriter(SaveINI.FileName)
                setStatus("Skip", 2)
                writer.WriteLine("[JustAPendulum]")
                setStatus("Skip", 3)
                writer.WriteLine("Calibration_value = " & CalibrateBox.Value.ToString)
                setStatus("Skip", 4)
                writer.WriteLine("Length = " & LengthBox.Value.ToString)
                setStatus("Skip", 5)
                writer.WriteLine("Length_error = " & eLengthBox.Value.ToString)
                setStatus("Skip", 6)
                writer.Close()
                setStatus("Saved! Ready", 7)
            Else
                setStatus("Ready")
            End If
        Catch ex As Exception
            setStatus("Unable to save a configuration file.")
            Debug.Print("Unable to save the INI file: " & ex.Message)
        End Try
    End Sub

    Private Sub Start_Click(sender As Object, e As EventArgs) Handles Start.Click
        Try
            Pendulum.WriteLine(1)   'Start the measurements
        Catch ex As Exception
            setStatus("Unable to send a starting message.")
            Debug.Print("Unable to send the message: " & ex.Message)
        End Try
    End Sub

    Private Sub LengthButton_Click(sender As Object, e As EventArgs) Handles LengthButton.Click
        StartLength()
    End Sub

    Private Sub StartLength()
        'Change the current length
        ADCMonitor.Checked = False
        BallTracking.Checked = False
        Disable_Animation()
        Calibrate.Enabled = False
        LengthButton.Enabled = False
        Loader.Enabled = False
        Saver.Enabled = False
        LengthPanel.Show()
        eLengthPanel.Show()
    End Sub

    Private Sub LengthBox_KeyPress(sender As Object, e As KeyPressEventArgs) Handles LengthBox.KeyPress
        'Send the new leght to Arduino
        Try
            If e.KeyChar = ChrW(Keys.Enter) Then
                Pendulum.WriteLine((LengthBox.Value * 1000) + 1080)
                LengthPanel.Hide()
                Calibrate.Enabled = True
                LengthButton.Enabled = True
                Loader.Enabled = True
                Saver.Enabled = True
            End If
        Catch ex As Exception
            setStatus("Unable to set the length.")
            Debug.Print("Unable to set the length: " & ex.Message)
        End Try
    End Sub

    Private Sub eLengthBox_KeyPress(sender As Object, e As KeyPressEventArgs) Handles eLengthBox.KeyPress
        'Change the measuremt error of the length
        Try
            If e.KeyChar = ChrW(Keys.Enter) Then
                Pendulum.WriteLine(eLengthBox.Value + 3090)
                eLengthPanel.Hide()
                Calibrate.Enabled = True
                LengthButton.Enabled = True
                Loader.Enabled = True
                Saver.Enabled = True
            End If
        Catch ex As Exception
            setStatus("Unable to set the error.")
            Debug.Print("Unable to set the error: " & ex.Message)
        End Try
    End Sub

    Private Sub Home_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Displays a welcome message and change the version
        Notify.ShowBalloonTip(3)
        VersionBox.Text = "Version " & My.Application.Info.Version.ToString
    End Sub

    Private Sub CloseButton_Click(sender As Object, e As EventArgs) Handles CloseButton.Click
        CloseForm.Show()
    End Sub

    Private Sub ConnectdisconnectToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ConnectdisconnectToolStripMenuItem.Click
        ConnectToPendulum()
    End Sub

    Private Sub AnimationToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AnimationToolStripMenuItem.Click
        Disable_Animation()
    End Sub

    Private Sub BallTrackingToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles BallTrackingToolStripMenuItem.Click
        BallTracking.Checked = False
    End Sub

    Private Sub ADCMonitorToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ADCMonitorToolStripMenuItem.Click
        ADCMonitor.Checked = False
    End Sub

    Private Sub CloseToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CloseToolStripMenuItem.Click
        CloseForm.Show()
    End Sub

    Private Sub ClearAllToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ClearAllToolStripMenuItem.Click
        Disable_Animation()
        BallTracking.Checked = False
        ADCMonitor.Checked = False
        PeriodBox.Clear()
        ErrorBox.Clear()
        gBox.Clear()
        e_gBox.Clear()
        setStatus("Ready", 0, 0)
        A0Box.Clear()
        A1Box.Clear()
        A2Box.Clear()
    End Sub

    Private Sub CalibrationToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CalibrationToolStripMenuItem.Click
        If Pendulum.IsOpen Then     'Check the connection
            StartCalibration()      'Change the calibration value
        Else
            setStatus("Not connected!")
        End If
    End Sub

    Private Sub WireLengthToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles WireLengthToolStripMenuItem.Click
        If Pendulum.IsOpen Then     'Check the connection
            StartLength()           'Change the length of the wire
        Else
            setStatus("Not connected!")
        End If
    End Sub

    Private Sub LoadINIToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LoadINIToolStripMenuItem.Click
        If Pendulum.IsOpen Then     'Check the connection
            StartLoading()          'Load an INI file
        Else
            setStatus("Not connected!")
        End If
    End Sub

    Private Sub SaveINIToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaveINIToolStripMenuItem.Click
        If Pendulum.IsOpen Then     'Check the connection
            StartSaving()           'Save an INI file
        Else
            setStatus("Not connected!")
        End If
    End Sub

    Private Sub StartMeasurementsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles StartMeasurementsToolStripMenuItem.Click
        Try
            If Pendulum.IsOpen Then     'Check the connection
                Pendulum.WriteLine(1)   'Start command
            Else
                setStatus("Not connected!")
            End If
        Catch ex As Exception
            setStatus("Unable to send the message!")
            Debug.Print("Unable to send the message: " & ex.Message)
        End Try
    End Sub

    Private Sub AVRResetToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AVRResetToolStripMenuItem.Click
        Try
            If Pendulum.IsOpen Then     'Check the connection
                Pendulum.WriteLine(2)   'AVR reset command
            Else
                setStatus("Not connected!")
            End If
        Catch ex As Exception
            setStatus("Unable to send the message!")
            Debug.Print("Unable to send the message: " & ex.Message)
        End Try
    End Sub

    Private Sub Link_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles Link.LinkClicked
        Process.Start("https://goo.gl/AxUGIP")      'Visit my website
    End Sub

    Private Sub PortsBox_SelectedIndexChanged(sender As Object, e As EventArgs) Handles PortsBox.SelectedIndexChanged
        startConnection(PortsBox.SelectedItem)
    End Sub

    Private Sub NumericUpDown1_ValueChanged(sender As Object, e As EventArgs) Handles SpeedRating.ValueChanged
        Receiver.Interval = SpeedRating.Value
    End Sub

    Private Sub Excel_export_Click(sender As Object, e As EventArgs) Handles Excel_export.Click
        'Excel .xls file export
        'The first thing to do is change the title and the filter of the SaveINI component
        SaveINI.Title = "Export xls file for Excel"
        SaveINI.Filter = "Comma-separated values (.csv)|*.csv"

        Try
            setStatus("Exporting...", 0, 4)

            If SaveINI.ShowDialog() = DialogResult.OK Then
                setStatus("Skip", 1)
                Dim writer As New IO.StreamWriter(SaveINI.FileName)
                setStatus("Skip", 2)
                'Creative commons & autor
                writer.WriteLine("JustAPendulum,marcocipriani01,CC BY-NC-SA")
                writer.WriteLine("Oscillation period (ms),Gravitational acceleration (m/s^2)")
                setStatus("Skip", 3)

                Dim a As Integer = 0
                Dim b As String = ""
                Dim c As String = ""

                'Save each element in the table
                While a <> Table.Items.Count
                    b = Table.Items(a).Text.ToString                 '1st column
                    c = Table.Items(a).SubItems(0).Text.ToString     '2nd column

                    If b <> "" And c <> "" Then     'Delete a bug with b & c = ""
                        writer.Write(b)
                        writer.Write(",")
                        writer.Write(c)
                    End If

                    a = a + 1       'Go to the next column
                End While

                writer.Close()
                setStatus("Skip", 3)

                MsgBox("Export finished! Opening Excel...", MsgBoxStyle.MsgBoxRight, "JustAPendulum Excel exporter")
                Process.Start(SaveINI.FileName)
                setStatus("Skip", 4)
            End If
            setStatus("Ready", 0, 0)

        Catch ex As Exception
            setStatus("Unable to export!", 0)
            Debug.Print("Unable to export: " & ex.Message)
        End Try

        'Restore the filter
        SaveINI.Title = "Save a configuration file"
        SaveINI.Filter = "Configuration file (.ini)|*.ini"
    End Sub

    Private Sub BallTracking_CheckedChanged(sender As Object, e As EventArgs) Handles BallTracking.CheckedChanged
        TrackingSound.Enabled = BallTracking.Checked
        Disable_Animation()
    End Sub

    Private Sub ADCMonitor_CheckedChanged(sender As Object, e As EventArgs) Handles ADCMonitor.CheckedChanged
        Disable_Animation()
    End Sub
End Class
